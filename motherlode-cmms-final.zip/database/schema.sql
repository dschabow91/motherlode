
CREATE TABLE IF NOT EXISTS technicians (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT CHECK (role IN ('admin','tech')) NOT NULL,
    active BOOLEAN DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS daily_reports (
    id SERIAL PRIMARY KEY,
    technician_id INTEGER REFERENCES technicians(id),
    shift TEXT,
    report_text TEXT,
    report_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pm_tasks (
    id SERIAL PRIMARY KEY,
    title TEXT,
    description TEXT,
    assigned_to INTEGER REFERENCES technicians(id),
    due_date DATE,
    completed BOOLEAN DEFAULT FALSE,
    completed_date DATE
);
CREATE TABLE IF NOT EXISTS inventory (
    id SERIAL PRIMARY KEY,
    part_name TEXT,
    stock_quantity INTEGER,
    reorder_threshold INTEGER,
    unit TEXT
);
CREATE TABLE IF NOT EXISTS reorder_requests (
    id SERIAL PRIMARY KEY,
    inventory_id INTEGER REFERENCES inventory(id),
    requested_by INTEGER REFERENCES technicians(id),
    status TEXT DEFAULT 'pending',
    requested_date DATE DEFAULT CURRENT_DATE,
    fulfilled_date DATE
);
