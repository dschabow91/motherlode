
INSERT INTO technicians (name, email, password_hash, role) VALUES
('Admin', 'admin@motherlode.com', '$2a$10$eW5JLPLFZLj6vJYIFZfQmeQdyVmj4pq4LQKsmSyBr9NwhgG2KqU.6', 'admin'),
('Tech', 'tech@motherlode.com', '$2a$10$Vv/jzAMzMj4Uk12zL1chBeN/McFZzUvOEv05GIVJXXkGo3Ru0r3ny', 'tech');
